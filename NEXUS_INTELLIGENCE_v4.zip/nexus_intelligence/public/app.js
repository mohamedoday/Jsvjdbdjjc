const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showView(id){$$(".view").forEach(v=>v.classList.toggle("hidden",v.id!==id));$$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===id));$("#pageName").textContent=({overview:"Overview",domain:"Domain intelligence",ip:"IP / RDAP lookup",tls:"TLS certificate",metadata:"File metadata",cases:"Case manager",scope:"Scope manager",reports:"Report center"})[id];window.scrollTo(0,0)}
$$(".nav").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.go)));
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
async function post(url,body){const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw new Error(d.error||"Request failed");return d}
function busy(button,on,label){button.disabled=on;button.dataset.old ||= button.innerHTML;button.innerHTML=on?"Working…":button.dataset.old}
function renderRecords(target,data){target.classList.remove("empty");target.innerHTML=`<div class="result-head"><b>Lookup results</b><span>${escapeHtml(data.checkedAt||"")}</span></div><div class="record-grid">${Object.entries(data.records||{}).map(([k,v])=>`<div class="record"><label>${escapeHtml(k)}</label><pre>${escapeHtml(JSON.stringify(v,null,2))}</pre></div>`).join("")}</div><button class="secondary export-one">Export JSON</button>`;target.querySelector(".export-one").onclick=()=>download(JSON.stringify(data,null,2),"nexus-dns-result.json","application/json")}
function renderKv(target,data){target.classList.remove("empty");target.innerHTML=`<div class="result-head"><b>Lookup results</b><span>${escapeHtml(data.checkedAt||"")}</span></div>${Object.entries(data).filter(([k])=>k!=="checkedAt").map(([k,v])=>`<div class="kv"><span>${escapeHtml(k)}</span><b>${escapeHtml(typeof v==="object"?JSON.stringify(v):v??"—")}</b></div>`).join("")}<button class="secondary export-one">Export JSON</button>`;target.querySelector(".export-one").onclick=()=>download(JSON.stringify(data,null,2),"nexus-result.json","application/json")}
$("#dnsRun").onclick=async()=>{const b=$("#dnsRun");busy(b,true);try{const d=await post("/api/dns",{host:$("#dnsHost").value});renderRecords($("#dnsResult"),d)}catch(e){toast(e.message)}finally{busy(b,false)}};
$("#rdapRun").onclick=async()=>{const b=$("#rdapRun");busy(b,true);try{renderKv($("#rdapResult"),await post("/api/rdap",{query:$("#rdapQuery").value}))}catch(e){toast(e.message)}finally{busy(b,false)}};
$("#tlsRun").onclick=async()=>{const b=$("#tlsRun");busy(b,true);try{renderKv($("#tlsResult"),await post("/api/tls",{host:$("#tlsHost").value}))}catch(e){toast(e.message)}finally{busy(b,false)}};
function download(content,name,type){const a=document.createElement("a"),url=URL.createObjectURL(new Blob([content],{type}));a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}

function parseJpegExif(view){
  const out={}; let p=2, tiff=-1;
  const readAscii=(off,n)=>{let s="";for(let i=0;i<n&&off+i<view.byteLength;i++){const c=view.getUint8(off+i);if(!c)break;s+=String.fromCharCode(c)}return s};
  while(p+4<view.byteLength){
    if(view.getUint8(p)!==255)break;
    const marker=view.getUint8(p+1),len=view.getUint16(p+2);
    if(marker===0xE1 && readAscii(p+4,6)==="Exif\u0000\u0000"){tiff=p+10;break}
    if(len<2)break;p+=2+len;
  }
  if(tiff<0 || tiff+8>view.byteLength)return {"EXIF":"No EXIF segment found"};
  const order=readAscii(tiff,2),le=order==="II";
  if(!le && order!=="MM")return {"EXIF":"Invalid TIFF byte order"};
  const u16=o=>view.getUint16(o,le),u32=o=>view.getUint32(o,le);
  if(u16(tiff+2)!==42)return {"EXIF":"Unsupported TIFF header"};
  const base=tiff, first=base+u32(base+4), tags={};
  const typeSize={1:1,2:1,3:2,4:4,5:8,7:1,9:4,10:8};
  function ifd(offset,prefix="",depth=0){
    if(depth>2||offset+2>view.byteLength)return;
    const count=u16(offset);
    for(let i=0;i<count;i++){
      const e=offset+2+i*12;if(e+12>view.byteLength)break;
      const tag=u16(e),type=u16(e+2),n=u32(e+4),size=(typeSize[type]||0)*n;
      if(!size||n>1000)continue;
      const valOff=size<=4?e+8:base+u32(e+8);
      if(valOff<0||valOff+Math.min(size,256)>view.byteLength)continue;
      const names={0x010F:"Camera make",0x0110:"Camera model",0x0132:"Date modified",0x9003:"Date taken",0x9004:"Date digitized",0x829A:"Exposure time",0x829D:"F-number",0x8827:"ISO",0x920A:"Focal length",0xA002:"Image width",0xA003:"Image height"};
      if(names[tag]){
        let value;
        if(type===2)value=readAscii(valOff,Math.min(n,128));
        else if(type===3)value=n===1?u16(valOff):Array.from({length:Math.min(n,8)},(_,j)=>u16(valOff+j*2)).join(", ");
        else if(type===4)value=n===1?u32(valOff):Array.from({length:Math.min(n,8)},(_,j)=>u32(valOff+j*4)).join(", ");
        else if(type===5&&n===1){const num=u32(valOff),den=u32(valOff+4);value=den?`${num}/${den} (${(num/den).toFixed(3)})`:`${num}/0`;}
        else value=`${n} value(s)`;
        tags[names[tag]]=value;
      }
      if(tag===0x8769 && type===4)ifd(base+u32(e+8),"exif",depth+1);
      if(tag===0x8825)tags["GPS metadata"]="Present (location details not displayed)";
    }
  }
  ifd(first);
  return Object.keys(tags).length?tags:{"EXIF":"No supported camera tags found"};
}
$("#metaFile").onchange=async e=>{const file=e.target.files[0];if(!file)return;const box=$("#metaResult");box.classList.remove("empty");box.textContent="Reading locally…";const base={fileName:file.name,mimeType:file.type,sizeBytes:file.size,lastModified:new Date(file.lastModified).toISOString()};try{const buf=await file.arrayBuffer();const view=new DataView(buf);let dims="Not available";if(file.type==="image/png"&&buf.byteLength>24)dims=`${view.getUint32(16)} × ${view.getUint32(20)}`;else if(file.type==="image/jpeg"){let i=2;while(i<buf.byteLength-9){if(view.getUint8(i)!==255){i++;continue}const marker=view.getUint8(i+1),len=view.getUint16(i+2);if([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker)){dims=`${view.getUint16(i+7)} × ${view.getUint16(i+5)}`;break}if(len<2)break;i+=2+len}}base.dimensions=dims;
if(file.type==="image/jpeg"){
  const exif=parseJpegExif(new DataView(buf));
  Object.assign(base,exif);
}
base.privacyNote="No image bytes were uploaded or retained by the server.";box.innerHTML=`<div class="result-head"><b>Local file details</b><span>PROCESSED IN BROWSER</span></div>${Object.entries(base).map(([k,v])=>`<div class="kv"><span>${escapeHtml(k)}</span><b>${escapeHtml(v)}</b></div>`).join("")}<button class="secondary" id="metaExport">Export details</button>`;$("#metaExport").onclick=()=>download(JSON.stringify(base,null,2),"nexus-file-metadata.json","application/json")}catch(err){box.textContent="Could not inspect this file."}};

let cases=[];
let sessionToken=localStorage.getItem("nexus-session")||"";
let currentUser="";
const originalFetch=window.fetch.bind(window);
window.fetch=(url,opts={})=>{
  opts.headers={...(opts.headers||{})};
  if(sessionToken) opts.headers["x-nexus-session"]=sessionToken;
  return originalFetch(url,opts);
};
async function loadCases(){
  try{const d=await fetch("/api/cases").then(r=>r.json());cases=d.items||[];drawCases()}catch(e){}
}
function drawCases(){
  const el=$("#caseList"); if(!el)return;
  el.classList.remove("empty");
  if(!cases.length){el.textContent="No cases yet. Create your first case above.";el.classList.add("empty");return}
  el.innerHTML=cases.map(c=>`<div class="case-item"><b>${escapeHtml(c.title)}</b><p>${escapeHtml(c.notes||"No notes added.")}</p><small>${escapeHtml(c.createdAt)}</small> <button class="secondary" data-del="${c.id}">Delete</button></div>`).join("");
  $$("[data-del]").forEach(b=>b.onclick=async()=>{await fetch("/api/cases/"+b.dataset.del,{method:"DELETE"});await loadCases();toast("Case deleted.")});
}
$("#caseAdd").onclick=async()=>{
  const title=$("#caseTitle").value.trim();if(!title)return toast("Enter a case title.");
  try{const r=await fetch("/api/cases",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title,notes:$("#caseNotes").value.trim()})});const d=await r.json();if(!r.ok)throw new Error(d.error);$("#caseTitle").value="";$("#caseNotes").value="";cases=d.items;drawCases();refreshDashboard();toast("Case saved to SQLite.")}catch(e){toast(e.message)}
};
$("#caseExport").onclick=()=>download(JSON.stringify(cases,null,2),"nexus-cases.json","application/json");
$("#caseTxt").onclick=()=>download(cases.map(c=>`${c.title}\n${c.createdAt}\n${c.notes}\n${"—".repeat(40)}`).join("\n\n")||"No cases.", "nexus-cases.txt","text/plain");

// Authorized scope manager: DNS and TLS checks are gated by explicit scope registration.
async function loadScope(){
  const el=$("#scopeList"); if(!el) return;
  try{
    const data=await fetch("/api/scope").then(r=>r.json());
    el.classList.remove("empty");
    if(!data.items.length){el.textContent="No authorized domains registered yet.";el.classList.add("empty");return}
    el.innerHTML=`<div class="result-head"><b>Authorized assets (${data.items.length})</b><span>LOCAL SERVER STORAGE</span></div>`+
      data.items.map(x=>`<div class="case-item"><b>${escapeHtml(x.host)}</b><p>${escapeHtml(x.owner||"Owner not specified")}</p><small>Added ${escapeHtml(x.addedAt||x.added_at)} · Authorization confirmed</small> <button class="secondary" data-scope-del="${x.id}">Remove</button></div>`).join("");
    $$("[data-scope-del]").forEach(b=>b.onclick=async()=>{await fetch("/api/scope/"+b.dataset.scopeDel,{method:"DELETE"});loadScope();toast("Asset removed from scope.")});
  }catch(e){el.textContent="Could not load scope list."}
}
$("#scopeAdd")?.addEventListener("click",async()=>{
  const b=$("#scopeAdd");busy(b,true);
  try{
    const r=await fetch("/api/scope",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({host:$("#scopeHost").value,owner:$("#scopeOwner").value,authorization:$("#scopeConfirm").checked})});
    const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not add domain");
    $("#scopeHost").value="";$("#scopeOwner").value="";$("#scopeConfirm").checked=false;
    await loadScope();toast("Authorized domain added.");
  }catch(e){toast(e.message)}finally{busy(b,false)}
});
$("#reportGenerate")?.addEventListener("click",async()=>{
  const [scopeData]=await Promise.all([fetch("/api/scope").then(r=>r.json())]);
  const title=$("#reportTitle").value.trim()||"NEXUS Intelligence Report";
  const esc=escapeHtml;
  const caseHtml=cases.length?cases.map(c=>`<article><h3>${esc(c.title)}</h3><small>${esc(c.createdAt)}</small><p>${esc(c.notes||"No notes recorded.")}</p></article>`).join(""):"<p>No case notes recorded.</p>";
  const scopeHtml=scopeData.items.length?scopeData.items.map(x=>`<li>${esc(x.host)} — ${esc(x.owner||"Owner not specified")}</li>`).join(""):"<li>No authorized assets registered.</li>";
  const htmlDoc=`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{font:14px Arial,sans-serif;max-width:850px;margin:40px auto;color:#172033;line-height:1.6}h1{border-bottom:3px solid #1b8e87;padding-bottom:14px}h2{margin-top:30px;color:#176d70}article{border:1px solid #dbe2ea;padding:14px;margin:12px 0;border-radius:8px}small{color:#66758a}footer{margin-top:40px;border-top:1px solid #ddd;padding-top:12px;color:#68758a}@media print{button{display:none}}</style></head><body><button onclick="window.print()">Print / Save as PDF</button><h1>${esc(title)}</h1><p>Generated: ${new Date().toLocaleString()}</p><p>This report summarizes locally recorded case notes and registered authorized scope. It is not a certification or a guarantee of security.</p><h2>Authorized scope</h2><ul>${scopeHtml}</ul><h2>Case notes</h2>${caseHtml}<footer>NEXUS INTELLIGENCE · Responsible research only</footer></body></html>`;
  const preview=$("#reportPreview");preview.classList.remove("empty");preview.innerHTML=`<div class="result-head"><b>Report generated</b><span>${new Date().toLocaleString()}</span></div><p>Report prepared with ${cases.length} case(s) and ${scopeData.items.length} authorized asset(s).</p><button class="secondary" id="reportOpen">Open printable report</button> <button class="secondary" id="reportDownload">Download HTML</button>`;
  $("#reportOpen").onclick=()=>{const w=window.open("","_blank");w.document.write(htmlDoc);w.document.close()};
  $("#reportDownload").onclick=()=>download(htmlDoc,"nexus-assessment-report.html","text/html");
});
loadScope();


// First-run local administrator setup / login.
async function authInit(){
  const status=await originalFetch("/api/auth/status").then(r=>r.json());
  if(sessionToken){try{const d=await originalFetch("/api/dashboard",{headers:{"x-nexus-session":sessionToken}}).then(r=>r.json());if(!d.error){showApp();return}}catch(e){}}
  $("#appShell").classList.add("hidden");$("#authGate").classList.remove("hidden");
  $("#authTitle").textContent=status.setupRequired?"Create your local administrator":"Welcome back";
  $("#authDesc").textContent=status.setupRequired?"Set up the administrator account for this device.":"Sign in to your local NEXUS workspace.";
  $("#authSubmit").textContent=status.setupRequired?"Create account ↗":"Sign in ↗";
  $("#authHint").textContent=status.setupRequired?"Use a unique password with at least 12 characters.":"Your account is stored locally on this device.";
  $("#authSubmit").onclick=async()=>{
    const payload={username:$("#authUser").value,password:$("#authPass").value};
    try{
      const r=await originalFetch(status.setupRequired?"/api/auth/setup":"/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
      const d=await r.json();if(!r.ok)throw new Error(d.error||"Authentication failed.");
      sessionToken=d.token;currentUser=d.username;localStorage.setItem("nexus-session",sessionToken);showApp();
    }catch(e){$("#authError").textContent=e.message}
  };
}
function showApp(){
  $("#authGate").classList.add("hidden");$("#appShell").classList.remove("hidden");
  $("#pageName").textContent="Overview";showView("overview");loadCases();loadScope();refreshDashboard();
}
async function refreshDashboard(){
  try{
    const d=await fetch("/api/dashboard").then(r=>r.json());
    const stats=$("#overview .stats");
    if(stats) stats.innerHTML=`<div class="stat"><span>AUTHORIZED ASSETS</span><b>${d.scopeCount}</b><small>Registered in scope manager</small></div><div class="stat"><span>CASE FILES</span><b>${d.caseCount}</b><small>Stored in local SQLite</small></div><div class="stat"><span>SAVED FINDINGS</span><b>${d.findingCount}</b><small>Recorded observations</small></div>`;
  }catch(e){}
}
$("#researchRun")?.addEventListener("click",()=>{
  const q=$("#researchQuery").value.trim();if(!q)return toast("Enter a research subject.");
  const enc=encodeURIComponent('"'+q+'"');
  const links=[
    ["General web search","https://www.google.com/search?q="+enc],
    ["News search","https://www.google.com/search?tbm=nws&q="+enc],
    ["Public documents","https://www.google.com/search?q="+enc+"+filetype%3Apdf"],
    ["GitHub public repositories","https://github.com/search?q="+encodeURIComponent(q)+"&type=repositories"],
    ["Internet Archive","https://web.archive.org/web/*/"+encodeURIComponent(q)]
  ];
  const el=$("#researchResults");el.classList.remove("empty");
  el.innerHTML=`<div class="result-head"><b>Public-source search links</b><span>OPEN IN BROWSER</span></div>`+links.map(([name,url])=>`<div class="kv"><span>${escapeHtml(name)}</span><b><a href="${url}" target="_blank" rel="noopener noreferrer">Open search ↗</a></b></div>`).join("")+`<p class="muted">Review results manually. Respect website terms, privacy, and applicable law.</p>`;
});
async function loadAudit(){
  const el=$("#auditResults");if(!el)return;
  try{const d=await fetch("/api/audit").then(r=>r.json());el.classList.remove("empty");if(!d.items.length){el.textContent="No activity recorded.";return}
  el.innerHTML=`<div class="result-head"><b>Recent activity</b><span>${d.items.length} EVENTS</span></div>`+d.items.map(x=>`<div class="kv"><span>${escapeHtml(x.createdAt)}</span><b>${escapeHtml(x.action)} · ${escapeHtml(x.target||"")}<br><small>${escapeHtml(x.detail||"")}</small></b></div>`).join("");
  }catch(e){el.textContent="Could not load audit log."}
}
const oldShowView=showView;
showView=function(id){oldShowView(id);if(id==="audit")loadAudit();if(id==="scope")loadScope();if(id==="cases")loadCases()};
authInit();


// NEXUS OS desktop interactions: command palette, dock, appearance and clock.
const moduleIndex=[
 ["Overview","overview","◈"],["Domain intelligence","domain","⌘"],["IP / RDAP lookup","ip","◎"],
 ["TLS certificate","tls","◇"],["File metadata","metadata","▧"],["Case manager","cases","▤"],
 ["Scope manager","scope","⌖"],["Report center","reports","▥"],["Public research","research","⌕"],["Audit log","audit","≋"]
];
function setDockActive(id){
  $$(".dock-app").forEach(b=>b.classList.toggle("selected",b.dataset.go===id));
}
const baseShowView=showView;
showView=function(id){baseShowView(id);setDockActive(id)};
function openCommand(){
  const overlay=$("#commandOverlay");overlay.classList.remove("hidden");
  $("#commandInput").value="";renderCommand("");$("#commandInput").focus();
}
function closeCommand(){$("#commandOverlay").classList.add("hidden")}
function renderCommand(query){
  const q=query.toLowerCase().trim();
  const results=moduleIndex.filter(x=>x[0].toLowerCase().includes(q));
  $("#commandResults").innerHTML=results.map((x,i)=>`<div class="command-result ${i===0?"active":""}" data-command-view="${x[1]}"><span>${x[2]}</span><b>${x[0]}</b><small>OPEN ↵</small></div>`).join("")||'<div class="command-result">No matching modules</div>';
  $$("#commandResults [data-command-view]").forEach(el=>el.addEventListener("click",()=>{showView(el.dataset.commandView);closeCommand()}));
}
$("#commandOpen")?.addEventListener("click",openCommand);
$("#commandInput")?.addEventListener("input",e=>renderCommand(e.target.value));
$("#commandOverlay")?.addEventListener("click",e=>{if(e.target.id==="commandOverlay")closeCommand()});
$$(".dock-app").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.go)));
$("#themeToggle")?.addEventListener("click",()=>{
  document.body.classList.toggle("light-mode");
  localStorage.setItem("nexus-appearance",document.body.classList.contains("light-mode")?"light":"dark");
  toast(document.body.classList.contains("light-mode")?"Light glass appearance":"Dark glass appearance");
});
if(localStorage.getItem("nexus-appearance")==="light")document.body.classList.add("light-mode");
function updateClock(){
 const el=$("#topClock");if(!el)return;
 el.textContent=new Intl.DateTimeFormat(undefined,{hour:"2-digit",minute:"2-digit"}).format(new Date());
}
updateClock();setInterval(updateClock,15000);
document.addEventListener("keydown",e=>{
 if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){e.preventDefault();openCommand()}
 if(e.key==="Escape")closeCommand();
 if($("#commandOverlay")&&!$("#commandOverlay").classList.contains("hidden")&&e.key==="Enter"){
   const first=$("#commandResults [data-command-view]");if(first){showView(first.dataset.commandView);closeCommand()}
 }
});

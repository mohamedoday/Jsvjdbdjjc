# NEXUS INTELLIGENCE Desktop Setup (No Electron)

This source adds a native C# WinForms + Microsoft WebView2 desktop shell around the existing NEXUS 5.5.1 local Node/SQLite service. It does **not** use Electron.

## Build the Windows installer

Build on Windows x64 with:
- Node.js 22.x x64 and npm
- .NET 8 SDK
- Inno Setup 6
- Microsoft Edge WebView2 Runtime on target PCs (the Evergreen runtime is normally present on current Windows systems; install it if missing)

From PowerShell in this folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\build-windows.ps1
```

The script installs production npm dependencies on Windows so `better-sqlite3` is built for the correct Windows Node ABI, publishes the native host, bundles `node.exe`, then compiles `dist\NEXUS-Setup.exe`.

## Data and security

- User databases and sessions are stored in `%LOCALAPPDATA%\NEXUS Intelligence\data`, not in Program Files, so upgrades do not overwrite them.
- The service binds only to `127.0.0.1` on port 3210.
- A fresh random session secret is generated each app launch. This intentionally invalidates old sessions after app restart; user accounts and workspace data remain.
- On first launch, enter the owner email to enable the owner-only Admin Console. It is saved in `%LOCALAPPDATA%\NEXUS Intelligence\settings.json`.
- The app host stops the child Node process when the desktop window closes.
- This is a local desktop app. Do not expose its local service to the public internet.

## Notes

This repository contains the installer source and Windows build script. The final EXE installer must be compiled on Windows with the prerequisites above; this Linux workspace cannot validate a Windows-native `better-sqlite3` binary or execute the Inno Setup compiler.

using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Web.WebView2.Core;

namespace NexusDesktop;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class MainForm : Form
{
    private readonly Microsoft.Web.WebView2.WinForms.WebView2 web = new() { Dock = DockStyle.Fill };
    private Process? server;
    private readonly string root = AppContext.BaseDirectory;
    private readonly string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXUS Intelligence", "data");
    private const int Port = 3210;

    public MainForm()
    {
        Text = "NEXUS INTELLIGENCE";
        Width = 1440; Height = 900; MinimumSize = new Size(1000, 650);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(10, 15, 28);
        Controls.Add(web);
        Shown += async (_, _) => await StartNexusAsync();
        FormClosing += (_, _) => StopServer();
    }

    private async Task StartNexusAsync()
    {
        try
        {
            var appDir = Path.Combine(root, "app");
            var node = Path.Combine(root, "runtime", "node.exe");
            var entry = Path.Combine(appDir, "server.cjs");
            if (!File.Exists(node) || !File.Exists(entry))
                throw new FileNotFoundException("NEXUS runtime files are missing. Please reinstall the application.");

            Directory.CreateDirectory(dataDir);
            var settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXUS Intelligence", "settings.json");
            Directory.CreateDirectory(Path.GetDirectoryName(settingsPath)!);
            string? adminEmail = null;
            if (File.Exists(settingsPath))
            {
                try { adminEmail = JsonDocument.Parse(File.ReadAllText(settingsPath)).RootElement.GetProperty("adminEmail").GetString(); } catch { }
            }
            if (string.IsNullOrWhiteSpace(adminEmail))
            {
                var entered = Microsoft.VisualBasic.Interaction.InputBox("Enter the email address that will own the NEXUS Admin Console. Leave blank to configure it later.", "NEXUS Owner Setup", "").Trim();
                if (!string.IsNullOrWhiteSpace(entered))
                {
                    adminEmail = entered;
                    File.WriteAllText(settingsPath, JsonSerializer.Serialize(new { adminEmail }));
                }
            }

            var secret = Convert.ToHexString(RandomNumberGenerator.GetBytes(48));
            server = new Process
            {
                StartInfo = new ProcessStartInfo(node, $"\"{entry}\"")
                {
                    WorkingDirectory = appDir,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                },
                EnableRaisingEvents = true
            };
            server.StartInfo.Environment["PORT"] = Port.ToString();
            server.StartInfo.Environment["SESSION_SECRET"] = secret;
            server.StartInfo.Environment["NEXUS_DATA_DIR"] = dataDir;
            server.StartInfo.Environment["NODE_ENV"] = "production";
            server.StartInfo.Environment["COOKIE_SECURE"] = "false";
            if (!string.IsNullOrWhiteSpace(adminEmail)) server.StartInfo.Environment["ADMIN_EMAIL"] = adminEmail;
            server.Start();
            _ = DrainAsync(server.StandardOutput); _ = DrainAsync(server.StandardError);

            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(2) };
            var ready = false;
            for (var i = 0; i < 60; i++)
            {
                if (server.HasExited) throw new Exception("NEXUS server stopped during startup. Reinstall the application and try again.");
                try { var response = await client.GetAsync($"http://127.0.0.1:{Port}/health"); if (response.IsSuccessStatusCode) { ready = true; break; } } catch { }
                await Task.Delay(500);
            }
            if (!ready) throw new TimeoutException("NEXUS server did not become ready within 30 seconds.");

            await web.EnsureCoreWebView2Async();
            web.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            web.CoreWebView2.Settings.IsStatusBarEnabled = false;
            web.CoreWebView2.NavigationStarting += (_, e) =>
            {
                if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri)) return;
                if (uri.Host is not ("127.0.0.1" or "localhost"))
                {
                    e.Cancel = true;
                    try { Process.Start(new ProcessStartInfo(e.Uri) { UseShellExecute = true }); } catch { }
                }
            };
            web.Source = new Uri($"http://127.0.0.1:{Port}");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "NEXUS Startup Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Close();
        }
    }

    private static async Task DrainAsync(StreamReader reader)
    {
        try { while (await reader.ReadLineAsync() is not null) { } } catch { }
    }

    private void StopServer()
    {
        try { if (server is { HasExited: false }) { server.Kill(entireProcessTree: true); server.WaitForExit(3000); } } catch { }
        server?.Dispose();
    }
}

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 22 x64 is required on the build machine.' }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw 'npm is required on the build machine.' }
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET 8 SDK is required. Install from https://dotnet.microsoft.com/download/dotnet/8.0' }
$nodeMajor = [int]((node -p "process.versions.node.split('.')[0]").Trim())
if ($nodeMajor -ne 22) { throw "Build with Node.js 22.x x64. Current major: $nodeMajor" }

$app = Join-Path $root 'app'
$runtime = Join-Path $root 'runtime'
New-Item -ItemType Directory -Force $app,$runtime | Out-Null
Copy-Item (Join-Path $root 'server.cjs') $app -Force
Copy-Item (Join-Path $root 'public') $app -Recurse -Force
Copy-Item (Join-Path $root 'package.json') $app -Force
Push-Location $app
try {
  npm install --omit=dev
  if ($LASTEXITCODE -ne 0) { throw 'npm install failed.' }
  npm install-scripts approve better-sqlite3
  if ($LASTEXITCODE -ne 0) { throw 'Could not approve better-sqlite3 install script.' }
  npm rebuild better-sqlite3
  if ($LASTEXITCODE -ne 0) { throw 'better-sqlite3 native build failed. Install Visual Studio C++ Build Tools and retry.' }
} finally { Pop-Location }
Copy-Item (Join-Path (Split-Path (Get-Command node).Source -Parent) 'node.exe') (Join-Path $runtime 'node.exe') -Force

dotnet publish (Join-Path $root 'desktop-host\NexusDesktop.csproj') -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o (Join-Path $root 'desktop-publish')
if ($LASTEXITCODE -ne 0) { throw 'Desktop host publish failed.' }
$iss = Join-Path $root 'installer\NEXUS.iss'
$iscc = @('C:\Program Files (x86)\Inno Setup 6\ISCC.exe','C:\Program Files\Inno Setup 6\ISCC.exe') | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6 is required. Install from https://jrsoftware.org/isinfo.php' }
& $iscc $iss
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup compilation failed.' }
Write-Host "Installer created in $root\dist\NEXUS-Setup.exe" -ForegroundColor Green

# NEXUS INTELLIGENCE

A local-first OSINT and authorized asset-audit starter application with:
- Web interface (Express + static frontend)
- Windows/macOS/Linux desktop shell (Electron)
- DNS record lookup (A, AAAA, MX, NS, TXT, CNAME)
- Public RDAP lookup for domains and IP addresses
- TLS certificate inspection on HTTPS port 443
- Browser-local basic image metadata inspection
- Local case notes and JSON/TXT export

## Requirements
- Node.js 20 or newer
- npm

## Run as a web app
```bash
npm install
npm start
```
Open http://127.0.0.1:3030

## Run as a desktop app
After `npm install`, run:
```bash
npm run desktop
```
The desktop launcher starts the local API automatically.

## Package as a Windows installer
This starter includes Electron but not a signed installer pipeline. To create distributables, add `electron-builder` and configure Windows targets after testing on your own machine.

## Security and privacy
- The server binds only to 127.0.0.1.
- Uploaded files are not stored; the metadata screen reads image bytes in the browser.
- Cases are stored in browser localStorage on the current device/browser.
- DNS, RDAP, and TLS features make external requests to resolve public records.
- No port scanning, brute forcing, credential collection, account enumeration, exploitation, or access-control bypass is included.
- Only investigate domains/IPs you own or have explicit authorization to assess.
- Do not expose this local service directly to the public internet.

## Known limitations
- RDAP coverage and fields depend on the relevant registry.
- DNS results depend on the machine's configured resolver.
- TLS inspection is a basic certificate presentation check, not a compliance or vulnerability assessment.
- Basic image dimension reading is implemented; full EXIF parsing can be added in a later version.
- The desktop shell expects the local Express server to be started separately.


## Version 4.0 — NEXUS OS interface
- Liquid Glass desktop shell with translucent panels, layered blur and soft lighting.
- macOS-inspired top chrome and floating application dock.
- Command palette: Ctrl+K / Cmd+K, type a module, press Enter.
- Dock quick-launch for core modules.
- Dark / light glass appearance toggle, saved locally.
- Responsive layout for desktop and mobile.
- Reduced-motion preference support.
- The application remains a local-first web/Electron workspace; this is not a replacement operating system.


## Version 5.0 — Social Intelligence
- Added a Social Intelligence workspace with a 100-platform public-search directory.
- Searches are prepared as user-opened public web search links; NEXUS does not scrape, enumerate, or verify accounts.
- Requires the operator to confirm they own the username or have the account owner's permission.
- Email/phone reverse lookup and hidden account association discovery are intentionally unsupported.
- The directory is a public-link launcher, not 100 official API integrations.

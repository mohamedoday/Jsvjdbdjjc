const express = require("express");
const helmet = require("helmet");
const dns = require("node:dns").promises;
const tls = require("node:tls");
const https = require("node:https");
const path = require("node:path");
const fs = require("node:fs");
const crypto = require("node:crypto");
const db = require("./db.cjs");
const multer = require("multer");

const app = express();
const PORT = process.env.PORT || 3030;
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const sessions = new Map();
const now = () => new Date().toISOString();
const scrypt = (password, salt) => crypto.scryptSync(password, salt, 64).toString("hex");
function log(action, target="", detail="") {
  db.prepare("INSERT INTO audit_log(action,target,detail,created_at) VALUES(?,?,?,?)").run(action,target,detail,now());
}
function auth(req,res,next) {
  const token = String(req.headers["x-nexus-session"] || "");
  const session = sessions.get(token);
  if (!session) return res.status(401).json({error:"Please sign in to your local NEXUS workspace."});
  req.user = session;
  next();
}

const DATA_DIR = path.join(__dirname, "data");
const SCOPE_FILE = path.join(DATA_DIR, "authorized-scope.json");
function readScope() {
  return db.prepare("SELECT id,host,owner,added_at AS addedAt FROM scope ORDER BY added_at DESC").all();
}
function isInScope(host) {
  const clean = String(host).trim().toLowerCase();
  return readScope().some(item => clean === item.host || clean.endsWith("." + item.host));
}

function validHost(value) {
  if (typeof value !== "string") return false;
  const host = value.trim().toLowerCase();
  if (host.length > 253 || !/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*$/.test(host)) return false;
  return host.includes(".");
}
function validIp(value) {
  const net = require("node:net");
  return net.isIP(value) !== 0;
}
function getJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { "User-Agent": "NEXUS-INTELLIGENCE/1.0 contact: local-user" }, timeout: 10000 }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(data) }); }
        catch { reject(new Error("The upstream service returned an unreadable response.")); }
      });
    }).on("error", reject).on("timeout", function(){ this.destroy(new Error("Request timed out.")); });
  });
}

app.get("/api/health", (_req,res) => res.json({ok:true,app:"NEXUS INTELLIGENCE",mode:"local-first",version:"3.0.0"}));
app.get("/api/auth/status", (_req,res) => res.json({setupRequired:db.prepare("SELECT COUNT(*) AS n FROM users").get().n===0}));
app.post("/api/auth/setup", (req,res) => {
  const username=String(req.body.username||"").trim();
  const password=String(req.body.password||"");
  if (db.prepare("SELECT COUNT(*) AS n FROM users").get().n!==0) return res.status(409).json({error:"Local administrator is already configured."});
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) return res.status(400).json({error:"Username must be 3–32 characters: letters, numbers, dot, underscore or dash."});
  if (password.length<12 || password.length>128) return res.status(400).json({error:"Use a password between 12 and 128 characters."});
  const salt=crypto.randomBytes(16).toString("hex");
  db.prepare("INSERT INTO users(username,salt,password_hash,created_at) VALUES(?,?,?,?)").run(username,salt,scrypt(password,salt),now());
  log("account_created",username,"Local administrator setup");
  const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,{username});
  res.json({ok:true,token,username});
});
app.post("/api/auth/login", (req,res) => {
  const username=String(req.body.username||"").trim();
  const password=String(req.body.password||"");
  const user=db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || !crypto.timingSafeEqual(Buffer.from(scrypt(password,user.salt),"hex"),Buffer.from(user.password_hash,"hex"))) {
    log("login_failed",username,"Invalid local login");
    return res.status(401).json({error:"Invalid username or password."});
  }
  const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,{username});
  log("login",username,"Local session started");
  res.json({ok:true,token,username});
});
app.post("/api/auth/logout", auth, (req,res) => {
  const token=String(req.headers["x-nexus-session"]||""); sessions.delete(token);
  log("logout",req.user.username,"Local session ended"); res.json({ok:true});
});
app.get("/api/dashboard", auth, (_req,res) => {
  res.json({
    scopeCount:db.prepare("SELECT COUNT(*) AS n FROM scope").get().n,
    caseCount:db.prepare("SELECT COUNT(*) AS n FROM cases").get().n,
    findingCount:db.prepare("SELECT COUNT(*) AS n FROM findings").get().n,
    activity:db.prepare("SELECT action,target,detail,created_at AS createdAt FROM audit_log ORDER BY id DESC LIMIT 8").all()
  });
});
app.get("/api/scope", auth, (_req,res) => res.json({items:readScope()}));
app.post("/api/scope", auth, (req,res) => {
  const host=String(req.body.host||"").trim().toLowerCase();
  const owner=String(req.body.owner||"").trim().slice(0,120);
  if (!validHost(host)) return res.status(400).json({error:"Enter a valid domain name."});
  if (req.body.authorization!==true) return res.status(400).json({error:"Confirm ownership or explicit written permission."});
  if (db.prepare("SELECT id FROM scope WHERE host=?").get(host)) return res.status(409).json({error:"Domain already registered."});
  const id=crypto.randomUUID();
  db.prepare("INSERT INTO scope(id,host,owner,added_at) VALUES(?,?,?,?)").run(id,host,owner,now());
  log("scope_added",host,"Authorization confirmation recorded");
  res.json({ok:true,items:readScope()});
});
app.delete("/api/scope/:id", auth, (req,res) => {
  const item=db.prepare("SELECT host FROM scope WHERE id=?").get(req.params.id);
  db.prepare("DELETE FROM scope WHERE id=?").run(req.params.id);
  if(item) log("scope_removed",item.host,"Removed from authorized scope");
  res.json({ok:true,items:readScope()});
});
app.get("/api/cases", auth, (_req,res) => res.json({items:db.prepare("SELECT id,title,notes,created_at AS createdAt,updated_at AS updatedAt FROM cases ORDER BY created_at DESC").all()}));
app.post("/api/cases", auth, (req,res) => {
  const title=String(req.body.title||"").trim().slice(0,160), notes=String(req.body.notes||"").slice(0,10000);
  if(!title) return res.status(400).json({error:"Case title is required."});
  const id=crypto.randomUUID(), t=now();
  db.prepare("INSERT INTO cases(id,title,notes,created_at,updated_at) VALUES(?,?,?,?,?)").run(id,title,notes,t,t);
  log("case_created",title,"Case note saved");
  res.json({ok:true,items:db.prepare("SELECT id,title,notes,created_at AS createdAt,updated_at AS updatedAt FROM cases ORDER BY created_at DESC").all()});
});
app.delete("/api/cases/:id", auth, (req,res) => {
  db.prepare("DELETE FROM cases WHERE id=?").run(req.params.id);
  log("case_deleted",req.params.id,"Case removed");
  res.json({ok:true});
});
app.post("/api/findings", auth, (req,res) => {
  const kind=String(req.body.kind||"").slice(0,50), target=String(req.body.target||"").slice(0,253);
  const payload=JSON.stringify(req.body.payload||{});
  if(!kind || payload.length>50000) return res.status(400).json({error:"Invalid finding."});
  const id=crypto.randomUUID();
  db.prepare("INSERT INTO findings(id,case_id,kind,target,payload,created_at) VALUES(?,?,?,?,?,?)").run(id,req.body.caseId||null,kind,target,payload,now());
  log("finding_saved",target,kind);
  res.json({ok:true,id});
});
app.get("/api/findings", auth, (_req,res) => res.json({items:db.prepare("SELECT id,case_id AS caseId,kind,target,payload,created_at AS createdAt FROM findings ORDER BY created_at DESC LIMIT 200").all().map(x=>({...x,payload:JSON.parse(x.payload)}))}));
app.get("/api/audit", auth, (_req,res) => res.json({items:db.prepare("SELECT action,target,detail,created_at AS createdAt FROM audit_log ORDER BY id DESC LIMIT 300").all()}));

app.post("/api/dns", auth, async (req,res) => {
  const host = String(req.body.host || "").trim().toLowerCase();
  if (!validHost(host)) return res.status(400).json({ error:"Enter a valid public domain name." });
  if (!isInScope(host)) return res.status(403).json({error:"This domain is not in your authorized scope. Add it in Scope Manager first."});
  log("dns_lookup",host,"DNS record lookup");
  const types = ["A","AAAA","MX","NS","TXT","CNAME"];
  const results = {};
  await Promise.all(types.map(async type => {
    try {
      const rows = await dns.resolve(host, type);
      results[type] = rows.map(row => typeof row === "object" ? row : String(row));
    } catch (e) { results[type] = { note: e.code === "ENODATA" || e.code === "ENOTFOUND" ? "No records returned" : "Lookup unavailable" }; }
  }));
  res.json({ host, checkedAt:new Date().toISOString(), records:results, source:"System DNS resolver" });
});

app.post("/api/rdap", auth, async (req,res) => {
  const query = String(req.body.query || "").trim();
  if (!validIp(query) && !validHost(query)) return res.status(400).json({ error:"Enter a valid IP address or domain." });
  try {
    log("rdap_lookup",query,"Public RDAP lookup");
    const url = `https://rdap.org/${validIp(query) ? "ip" : "domain"}/${encodeURIComponent(query)}`;
    const out = await getJson(url);
    if (out.status >= 400) return res.status(502).json({ error:"RDAP registry did not return a record." });
    const d = out.data;
    res.json({
      query, handle:d.handle || d.ldhName || d.name || null,
      port43:d.port43 || null,
      country:d.country || null,
      status:d.status || [],
      events:(d.events || []).map(x=>({ action:x.eventAction, date:x.eventDate })),
      nameservers:(d.nameservers || []).map(x=>x.ldhName),
      entities:(d.entities || []).map(x=>({ roles:x.roles, handle:x.handle })),
      notices:(d.notices || []).map(x=>({ title:x.title, description:(x.description||[]).join(" ") })),
      source:"RDAP public registry", checkedAt:new Date().toISOString()
    });
  } catch(e) { res.status(502).json({ error:"RDAP lookup failed: " + e.message }); }
});

app.post("/api/tls", auth, async (req,res) => {
  const host = String(req.body.host || "").trim().toLowerCase();
  if (!validHost(host)) return res.status(400).json({ error:"Enter a valid public domain you own or are authorized to assess." });
  if (!isInScope(host)) return res.status(403).json({error:"This domain is not in your authorized scope. Add it in Scope Manager first."});
  log("tls_inspection",host,"TLS certificate inspection");
  const socket = tls.connect({ host, port:443, servername:host, timeout:8000, rejectUnauthorized:false }, () => {
    const cert = socket.getPeerCertificate(true);
    const result = {
      host, protocol:socket.getProtocol(), authorized:socket.authorized,
      authorizationError:socket.authorizationError || null,
      subject:cert.subject || {}, issuer:cert.issuer || {},
      validFrom:cert.valid_from || null, validTo:cert.valid_to || null,
      fingerprint256:cert.fingerprint256 || null,
      subjectAltName:cert.subjectaltname || null,
      checkedAt:new Date().toISOString(),
      note:"Certificate details only; this does not perform a vulnerability scan."
    };
    socket.end(); res.json(result);
  });
  socket.on("error", e => res.status(502).json({ error:"TLS inspection failed: " + e.message }));
  socket.on("timeout", () => { socket.destroy(); if (!res.headersSent) res.status(504).json({error:"TLS inspection timed out."}); });
});

app.post("/api/metadata", auth, upload.single("file"), (req,res) => {
  if (!req.file) return res.status(400).json({ error:"Choose a file first." });
  // The server intentionally does not retain or parse uploaded files.
  res.json({
    fileName:req.file.originalname, mimeType:req.file.mimetype,
    sizeBytes:req.file.size,
    note:"For privacy, file bytes are not saved. Use the browser-side metadata viewer for supported image EXIF fields."
  });
});

app.listen(PORT, "127.0.0.1", () => console.log(`NEXUS INTELLIGENCE running at http://127.0.0.1:${PORT}`));

const { app, BrowserWindow, shell } = require("electron");
const { spawn } = require("node:child_process");
const path = require("node:path");
const http = require("node:http");

let backend;
function waitForServer(timeoutMs=15000) {
  return new Promise((resolve,reject) => {
    const started = Date.now();
    const check = () => {
      const req = http.get("http://127.0.0.1:3030/api/health", res => {
        res.resume();
        if (res.statusCode === 200) resolve();
        else retry();
      });
      req.on("error", retry);
      req.setTimeout(700, () => req.destroy());
      function retry() {
        if (Date.now()-started > timeoutMs) reject(new Error("Local API did not start."));
        else setTimeout(check, 300);
      }
    };
    check();
  });
}
async function createWindow() {
  backend = spawn("node", [path.join(__dirname, "..", "server.cjs")], {
    cwd: path.join(__dirname, ".."),
    stdio: "ignore",
    windowsHide: true
  });
  const win = new BrowserWindow({
    width: 1440, height: 940, minWidth: 980, minHeight: 680,
    backgroundColor: "#080b13",
    webPreferences: { contextIsolation:true, nodeIntegration:false }
  });
  try { await waitForServer(); await win.loadURL("http://127.0.0.1:3030"); }
  catch (e) { win.loadURL("data:text/html,<h2>NEXUS backend could not start</h2><p>Install Node.js 20+ and run npm install in the project folder.</p>"); }
  win.webContents.setWindowOpenHandler(({url}) => {
    if (url.startsWith("https://")) shell.openExternal(url);
    return { action:"deny" };
  });
}
app.whenReady().then(createWindow);
app.on("before-quit", () => { if (backend && !backend.killed) backend.kill(); });
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });

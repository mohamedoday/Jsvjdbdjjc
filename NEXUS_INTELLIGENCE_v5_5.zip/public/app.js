const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const DBKEY='nexus_v53_local';
let db={cases:[]}, active=null, view='overview', authMode='login', currentUser=null, saveTimer=null;
function uid(){return 'nx_'+Math.random().toString(36).slice(2,10)}
function load(){try{return JSON.parse(localStorage.getItem(DBKEY))||{cases:[]}}catch{return {cases:[]}}}
function save(){localStorage.setItem(DBKEY,JSON.stringify(db));refreshCaseSelect()}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function current(){return db.cases.find(c=>c.id===active)}
function initCase(){if(!db.cases.length){const c={id:uid(),name:'My first investigation',description:'A workspace for verified public-source research.',created:new Date().toISOString(),entities:[],findings:[],links:[]};db.cases.push(c);active=c.id;save()}}

function refreshCaseSelect(){$('#caseSelect').innerHTML=db.cases.map(c=>`<option value="${c.id}" ${c.id===active?'selected':''}>${esc(c.name)}</option>`).join('')||'<option>No cases</option>'}
function toast(t){let el=$('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2300)}
const meta={
overview:['INTELLIGENCE OVERVIEW','Command Center','A clear operational picture of your verified research.'],
cases:['WORKSPACE MANAGEMENT','Investigation Cases','Keep each research scope independent and organized.'],
entities:['ENTITY REGISTER','Verified Entities','Public accounts and entities you have manually reviewed.'],
graph:['RELATIONSHIP INTELLIGENCE','Relationship Graph','Visualize only relationships supported by recorded public evidence.'],
findings:['EVIDENCE MANAGEMENT','Findings & Evidence','Record source-backed observations with confidence and review status.'],
analysis:['NEXUS AI','Analysis Workspace','Local heuristic synthesis of the records in this case.'],
analytics:['OPERATIONAL METRICS','Analytics Dashboard','A snapshot of coverage, evidence quality, and case activity.'],
settings:['SYSTEM & DATA','Data & Export','Back up or export your workspace.'],
admin:['OWNER CONSOLE','Admin Dashboard','Private system overview for the configured owner account.']
};
function go(v){if(v==='admin'&&currentUser?.role!=='admin'){toast('Owner access only');return}view=v;$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===v));$('#eyebrow').textContent=meta[v][0];$('#pageTitle').textContent=meta[v][1];$('#pageSub').textContent=meta[v][2];render()}
$$('.nav').forEach(n=>n.onclick=()=>go(n.dataset.view));
$('#caseSelect').onchange=e=>{active=e.target.value;render()};
$('#themeBtn').onclick=()=>document.body.classList.toggle('light');
$('#quickAdd').onclick=()=>openModal('case');
function openModal(type){
 const fields={
 case:[['name','Case name','text',''],['description','Purpose / scope','textarea','']],
 entity:[['name','Display name / username','text',''],['platform','Platform / source','text',''],['url','Public profile URL','url',''],['notes','Verification notes','textarea','']],
 finding:[['title','Finding title','text',''],['source','Public source URL','url',''],['details','Observation','textarea',''],['confidence','Confidence','select','']],
 link:[['from','Entity A','select',''],['to','Entity B','select',''],['label','Relationship type','text','Publicly documented connection'],['evidence','Evidence source URL','url','']]
 }[type];
 $('#modalTitle').textContent={case:'Create investigation case',entity:'Add verified public entity',finding:'Record public-source finding',link:'Add evidence-backed relationship'}[type];
 $('#modalFields').innerHTML=fields.map(([n,l,t,d])=>`<div class="field"><label>${l}</label>${t==='textarea'?`<textarea name="${n}" placeholder="${l}"></textarea>`:t==='select'?(n==='confidence'?`<select name="${n}"><option>High</option><option>Medium</option><option>Low</option></select>`:`<select name="${n}">${(current()?.entities||[]).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select>`):`<input name="${n}" type="${t}" value="${esc(d)}" placeholder="${l}" ${n==='name'||n==='title'?'required':''}>`}</div>`).join('');
 $('#modal').classList.remove('hidden');$('#modalForm').dataset.type=type;
}
function closeModal(){$('#modal').classList.add('hidden')}
$('#closeModal').onclick=$('#cancelModal').onclick=closeModal;
$('#modalForm').onsubmit=e=>{e.preventDefault();let type=e.target.dataset.type,fd=new FormData(e.target),o=Object.fromEntries(fd.entries());
 if(type==='case'){let c={id:uid(),name:o.name,description:o.description,created:new Date().toISOString(),entities:[],findings:[],links:[]};db.cases.push(c);active=c.id}
 else{let c=current();if(!c)return;if(type==='entity')c.entities.push({...o,id:uid(),verified:true,created:new Date().toISOString()});if(type==='finding')c.findings.push({...o,id:uid(),created:new Date().toISOString(),status:'Unreviewed'});if(type==='link'){if(o.from===o.to){toast('Choose two different entities');return}c.links.push({...o,id:uid(),created:new Date().toISOString(),verified:true})}}
 save();closeModal();render();toast('Record saved locally')};
function addBtn(label,type){return `<button class="primary" data-add="${type}">＋ ${label}</button>`}
function stat(label,value,foot){return `<div class="card"><div class="stat-label">${label}</div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></div>`}
function empty(msg){return `<div class="empty">${msg}</div>`}
function render(){refreshCaseSelect();let c=current();if(!c){$('#view').innerHTML=empty('Create a case to begin.');return}
 const v={
 overview:()=>overview(c),cases:()=>casesView(),entities:()=>entitiesView(c),findings:()=>findingsView(c),graph:()=>graphView(c),analysis:()=>analysisView(c),analytics:()=>analyticsView(c),settings:()=>settingsView(),admin:()=>adminView()
 }[view];$('#view').innerHTML=v();$$('[data-add]').forEach(b=>b.onclick=()=>openModal(b.dataset.add));$$('[data-delete]').forEach(b=>b.onclick=()=>removeRecord(b.dataset.delete,b.dataset.id));$$('[data-export]').forEach(b=>b.onclick=()=>exportData(b.dataset.export));if(view==='admin')loadAdmin();let analyze=$('#runAnalysis');if(analyze)analyze.onclick=()=>{$('#analysisResult').textContent=analyzeCase(c);};
}
function overview(c){let total=db.cases.length,entities=c.entities.length,findings=c.findings.length,links=c.links.length;
return `<div class="grid stats">${stat('ACTIVE CASES',total,'Independent workspaces')}${stat('VERIFIED ENTITIES',entities,'In selected case')}${stat('RECORDED FINDINGS',findings,'Public-source observations')}${stat('DOCUMENTED LINKS',links,'Manually verified connections')}</div>
<div class="grid two-col"><div class="card"><div class="section-title"><h3>Case activity</h3><span>SELECTED CASE</span></div><h2 style="font-size:20px;margin:0 0 8px">${esc(c.name)}</h2><p class="muted" style="font-size:12px;line-height:1.7">${esc(c.description||'No scope description added.')}</p><div class="list" style="margin-top:20px">${[['Entities',entities,'◎'],['Findings',findings,'◈'],['Relationships',links,'⌘']].map(x=>`<div class="list-row"><div class="dot-icon">${x[2]}</div><div><b>${x[0]}</b><small>Current case records</small></div><span class="right">${x[1]}</span></div>`).join('')}</div></div>
<div class="card"><div class="section-title"><h3>Recent findings</h3><span>NEWEST FIRST</span></div>${c.findings.length?`<div class="list">${[...c.findings].reverse().slice(0,5).map(f=>`<div class="list-row"><div class="dot-icon">◈</div><div><b>${esc(f.title)}</b><small>${esc(f.status)} · ${new Date(f.created).toLocaleDateString()}</small></div></div>`).join('')}</div>`:empty('No findings recorded yet.')}</div></div>
<div class="card" style="margin-top:15px"><div class="section-title"><h3>Responsible research reminder</h3><span>GUARDRAILS</span></div><p class="muted" style="font-size:12px;line-height:1.8;margin:0">Use public sources you are authorized to review. Record source URLs, distinguish confirmed facts from hypotheses, and avoid inferring a person's identity from username similarity alone.</p></div>`}
function casesView(){return `<div class="toolbar">${addBtn('Create case','case')}</div><div class="card"><div class="section-title"><h3>All investigation cases</h3><span>${db.cases.length} WORKSPACES</span></div><div class="list">${db.cases.map(c=>`<div class="list-row"><div class="dot-icon">▤</div><div><b>${esc(c.name)}</b><small>${esc(c.description||'No description')} · ${c.entities.length} entities · ${c.findings.length} findings</small></div><button class="mini-btn right" data-open-case="${c.id}">Open</button><button class="mini-btn" data-delete="case" data-id="${c.id}">Delete</button></div>`).join('')}</div></div>`}
function entitiesView(c){return `<div class="toolbar">${addBtn('Add verified entity','entity')}<input id="entitySearch" placeholder="Filter entities..."></div><div class="card table-wrap"><table class="data-table"><thead><tr><th>ENTITY</th><th>PLATFORM</th><th>PUBLIC PROFILE</th><th>STATUS</th><th></th></tr></thead><tbody id="entityRows">${c.entities.map(x=>`<tr><td><b>${esc(x.name)}</b><br><span class="muted">${esc(x.notes||'')}</span></td><td>${esc(x.platform)}</td><td>${x.url?`<a target="_blank" rel="noopener" href="${esc(x.url)}" style="color:var(--cyan)">Open source ↗</a>`:'—'}</td><td><span class="pill">MANUALLY VERIFIED</span></td><td><button class="mini-btn" data-delete="entity" data-id="${x.id}">Remove</button></td></tr>`).join('')}</tbody></table>${c.entities.length?'':empty('No verified entities in this case.')}</div>`}
function findingsView(c){return `<div class="toolbar">${addBtn('Add finding','finding')}</div><div class="card table-wrap"><table class="data-table"><thead><tr><th>FINDING</th><th>OBSERVATION</th><th>CONFIDENCE</th><th>SOURCE</th><th>STATUS</th><th></th></tr></thead><tbody>${c.findings.map(f=>`<tr><td><b>${esc(f.title)}</b><br><span class="muted">${new Date(f.created).toLocaleDateString()}</span></td><td>${esc(f.details)}</td><td><span class="pill">${esc(f.confidence)}</span></td><td>${f.source?`<a href="${esc(f.source)}" target="_blank" rel="noopener" style="color:var(--cyan)">View ↗</a>`:'—'}</td><td>${esc(f.status)}</td><td><button class="mini-btn" data-delete="finding" data-id="${f.id}">Remove</button></td></tr>`).join('')}</tbody></table>${c.findings.length?'':empty('No findings recorded.')}</div><div class="card" style="margin-top:14px"><p class="muted" style="font-size:11px;margin:0">Evidence quality improves when every observation includes a working source URL and a clear distinction between fact, interpretation, and uncertainty.</p></div>`}
function graphView(c){let n=c.entities.length;if(!n)return `<div class="toolbar">${addBtn('Add verified entity','entity')}</div><div class="card graph-card">${empty('Add verified entities, then record evidence-backed links to build the graph.')}</div>`;
let cx=420,cy=170,r=Math.min(125,35+n*9),pos={};c.entities.forEach((e,i)=>{let a=(2*Math.PI*i/n)-Math.PI/2;pos[e.id]={x:cx+r*Math.cos(a),y:cy+r*Math.sin(a),name:e.name}});
let lines=c.links.filter(l=>pos[l.from]&&pos[l.to]).map(l=>`<line x1="${pos[l.from].x}" y1="${pos[l.from].y}" x2="${pos[l.to].x}" y2="${pos[l.to].y}"><title>${esc(l.label)} · ${esc(l.evidence)}</title></line>`).join('');
let nodes=c.entities.map(e=>{let p=pos[e.id];return `<g><circle cx="${p.x}" cy="${p.y}" r="8"><title>${esc(e.name)}</title></circle><text x="${p.x}" y="${p.y+23}" text-anchor="middle">${esc(e.name.slice(0,20))}</text></g>`}).join('');
return `<div class="toolbar">${addBtn('Add entity','entity')}${addBtn('Add relationship','link')}</div><div class="card graph-card"><div class="section-title"><h3>Verified relationship map</h3><span>${c.entities.length} NODES · ${c.links.length} LINKS</span></div><svg class="graph-svg" viewBox="0 0 840 340" role="img" aria-label="Relationship graph">${lines}${nodes}</svg><p class="muted" style="font-size:10px">Edges represent manually verified public-source relationships. Hover nodes or lines for details.</p></div><div class="card" style="margin-top:14px"><div class="section-title"><h3>Documented connections</h3><span>WITH SOURCE</span></div>${c.links.length?`<div class="list">${c.links.map(l=>`<div class="list-row"><div class="dot-icon">↔</div><div><b>${esc(c.entities.find(e=>e.id===l.from)?.name||'Unknown')} ↔ ${esc(c.entities.find(e=>e.id===l.to)?.name||'Unknown')}</b><small>${esc(l.label)}</small></div><a class="right" href="${esc(l.evidence)}" target="_blank" rel="noopener">Evidence ↗</a><button class="mini-btn" data-delete="link" data-id="${l.id}">Remove</button></div>`).join('')}</div>`:empty('No relationships recorded. Add one only when a public source supports it.')}</div>`}
function analyzeCase(c){let lines=[];lines.push(`CASE: ${c.name}`);lines.push(`Entities manually verified: ${c.entities.length}`);lines.push(`Findings recorded: ${c.findings.length}`);lines.push(`Documented relationships: ${c.links.length}`);lines.push('');lines.push('OBSERVATIONS');if(!c.findings.length)lines.push('- No findings have been recorded.');c.findings.forEach(f=>lines.push(`- ${f.title} [${f.confidence||'Unrated'}]: ${f.details||'No detail supplied.'}`));lines.push('');lines.push('RELATIONSHIP REVIEW');if(!c.links.length)lines.push('- No source-backed links recorded.');c.links.forEach(l=>{let a=c.entities.find(e=>e.id===l.from)?.name||'Unknown',b=c.entities.find(e=>e.id===l.to)?.name||'Unknown';lines.push(`- ${a} — ${l.label} — ${b}. Evidence: ${l.evidence||'Missing source URL'}`)});lines.push('');lines.push('QUALITY CHECKS');let missing=c.findings.filter(f=>!f.source).length+c.links.filter(l=>!l.evidence).length;lines.push(`- Records missing source URLs: ${missing}`);lines.push('- Treat low-confidence observations as hypotheses, not established facts.');lines.push('- Similar handles, profile photos, or names alone do not establish shared ownership.');lines.push('');lines.push('NOTE: This is a local rule-based summary, not an external AI model or independent verification.');return lines.join('\\n')}
function analysisView(c){return `<div class="grid two-col"><div class="card"><div class="section-title"><h3>NEXUS AI synthesis</h3><span>LOCAL ANALYSIS ENGINE</span></div><p class="muted" style="font-size:12px;line-height:1.7">Generate a structured summary from this case's records. The analysis runs locally in your browser and does not independently verify sources.</p><button class="primary" id="runAnalysis">✧ Generate case analysis</button></div><div class="card"><div class="section-title"><h3>Analysis coverage</h3><span>INPUT RECORDS</span></div><div class="list"><div class="list-row"><div class="dot-icon">◎</div><div><b>Entities</b><small>Manually verified records</small></div><span class="right">${c.entities.length}</span></div><div class="list-row"><div class="dot-icon">◈</div><div><b>Findings</b><small>Recorded observations</small></div><span class="right">${c.findings.length}</span></div><div class="list-row"><div class="dot-icon">↔</div><div><b>Connections</b><small>Evidence-backed links</small></div><span class="right">${c.links.length}</span></div></div></div></div><div class="card" style="margin-top:15px"><div class="section-title"><h3>Analysis output</h3><span>GENERATED ON DEMAND</span></div><div class="analysis-output" id="analysisResult">Run the analysis to produce a case summary, relationship review, and evidence-quality checks.</div></div>`}
function analyticsView(c){let max=Math.max(1,c.entities.length,c.findings.length,c.links.length);return `<div class="grid stats">${stat('TOTAL CASES',db.cases.length,'All workspaces')}${stat('ENTITIES',c.entities.length,'Selected case')}${stat('FINDINGS',c.findings.length,'Selected case')}${stat('RELATIONSHIPS',c.links.length,'Selected case')}</div><div class="grid two-col"><div class="card"><div class="section-title"><h3>Record distribution</h3><span>SELECTED CASE</span></div>${[['Entities',c.entities.length],['Findings',c.findings.length],['Relationships',c.links.length]].map(([l,v])=>`<div class="bar-row"><span>${l}</span><div class="bar"><i style="width:${v/max*100}%"></i></div><b>${v}</b></div>`).join('')}</div><div class="card"><div class="section-title"><h3>Evidence completeness</h3><span>SOURCE URL CHECK</span></div>${(()=>{let total=c.findings.length+c.links.length,complete=c.findings.filter(x=>x.source).length+c.links.filter(x=>x.evidence).length,p=total?Math.round(complete/total*100):0;return `<div class="stat-value">${p}%</div><p class="muted" style="font-size:11px">${complete} of ${total} findings/links include a source URL.</p><div class="bar"><i style="width:${p}%"></i></div>`})()}</div></div>`}
function settingsView(){return `<div class="grid two-col"><div class="card"><div class="section-title"><h3>Export center</h3><span>PORTABLE DATA</span></div><p class="muted" style="font-size:12px;line-height:1.7">Export your local records for backup, review, or reporting. PDF uses your browser's print dialog.</p><div class="list"><button class="secondary" data-export="json">↓ Export full workspace (JSON)</button><button class="secondary" data-export="csv">↓ Export selected case (CSV)</button><button class="secondary" data-export="pdf">▧ Print selected case / Save as PDF</button></div></div><div class="card"><div class="section-title"><h3>Privacy & storage</h3><span>LOCAL ONLY</span></div><p class="muted" style="font-size:12px;line-height:1.8">Your data is stored in this browser's localStorage. This prototype has no server sync, account system, or cloud AI connection. Clearing site data may erase records; keep JSON backups.</p><span class="pill">NO SERVER TRANSMISSION</span></div></div>`}
function adminView(){
 return `<div class="grid stats" id="adminStats">${stat('TOTAL ACCOUNTS','—','Registered users')}${stat('WORKSPACES','—','User data stores')}${stat('INVESTIGATION CASES','—','Across all accounts')}${stat('ACCESS LEVEL','OWNER','Restricted to your email')}</div>
 <div class="card"><div class="section-title"><h3>Registered accounts</h3><span>RECENT 12</span></div><div id="adminUsers" class="muted" style="font-size:12px">Loading owner data…</div></div>
 <div class="card" style="margin-top:14px"><div class="section-title"><h3>Owner-only access</h3><span>SERVER ENFORCED</span></div><p class="muted" style="font-size:11px;line-height:1.8">Only the account whose email exactly matches ADMIN_EMAIL receives owner access. The server rechecks every admin API request.</p></div>`;
}
async function loadAdmin(){
 try{
  const d=await api('/admin/overview');
  const vals=[d.totals.users,d.totals.workspaces,d.totals.cases,'OWNER'];
  $('#adminStats').innerHTML=vals.map((v,i)=>stat(['TOTAL ACCOUNTS','WORKSPACES','INVESTIGATION CASES','ACCESS LEVEL'][i],v,['Registered users','User data stores','Across all accounts','Restricted to your email'][i])).join('');
  $('#adminUsers').innerHTML=d.recent.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>USERNAME</th><th>EMAIL</th><th>ROLE</th><th>CREATED</th></tr></thead><tbody>${d.recent.map(u=>`<tr><td><b>${esc(u.username)}</b></td><td>${esc(u.email)}</td><td><span class="pill">${u.role==='admin'?'OWNER':'USER'}</span></td><td>${esc(u.createdAt||'')}</td></tr>`).join('')}</tbody></table></div>`:empty('No accounts found.');
 }catch(e){$('#adminUsers').textContent=e.message}
}
function removeRecord(type,id){if(type==='case'){if(!confirm('Delete this case and all its local records?'))return;db.cases=db.cases.filter(c=>c.id!==id);if(!db.cases.length)db.cases.push({id:uid(),name:'New investigation',description:'',created:new Date().toISOString(),entities:[],findings:[],links:[]});active=db.cases[0].id}else{let c=current();let key={entity:'entities',finding:'findings',link:'links'}[type];c[key]=c[key].filter(x=>x.id!==id);if(type==='entity')c.links=c.links.filter(l=>l.from!==id&&l.to!==id)}save();render();toast('Record removed')}
function download(name,content,type){let a=document.createElement('a'),url=URL.createObjectURL(new Blob([content],{type}));a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
function exportData(type){let c=current();if(type==='json')download('nexus-workspace-backup.json',JSON.stringify(db,null,2),'application/json');if(type==='csv'){let rows=[['record_type','name_or_title','platform_or_confidence','details','source_url'],...c.entities.map(x=>['entity',x.name,x.platform,x.notes,x.url]),...c.findings.map(x=>['finding',x.title,x.confidence,x.details,x.source]),...c.links.map(x=>['relationship',`${c.entities.find(e=>e.id===x.from)?.name||''} -> ${c.entities.find(e=>e.id===x.to)?.name||''}`,x.label,'',x.evidence])];let csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\\r\\n');download('nexus-case-export.csv',csv,'text/csv')};if(type==='pdf'){go('overview');setTimeout(()=>window.print(),100)}}
$('#view').addEventListener('input',e=>{if(e.target.id==='entitySearch'){let q=e.target.value.toLowerCase();$$('#entityRows tr').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q)?'':'none')}});
$('#view').addEventListener('click',e=>{let b=e.target.closest('[data-open-case]');if(b){active=b.dataset.openCase;go('overview')}});

function setAuthMode(mode){
 authMode=mode;
 const reg=mode==='register';
 $('#authTitle').textContent=reg?'Create your account':'Welcome back';
 $('#authSubtitle').textContent=reg?'Create a private workspace for your investigations.':'Sign in to access your private investigation workspace.';
 $('#usernameField').classList.toggle('hidden',!reg);
 $('#confirmField').classList.toggle('hidden',!reg);
 $('#authForm [name="username"]').required=reg;
 $('#authForm [name="confirm"]').required=reg;
 $('#authForm [name="password"]').autocomplete=reg?'new-password':'current-password';
 $('#authSubmit').textContent=reg?'Create account':'Sign in';
 $('#authSwitch').innerHTML=reg?'Already registered? <button type="button" id="switchAuth">Sign in</button>':'New here? <button type="button" id="switchAuth">Create an account</button>';
 $('#switchAuth').onclick=()=>setAuthMode(reg?'login':'register');
 $('#authError').textContent='';
}
function showAuth(){ $('#authScreen').classList.remove('hidden'); $('#logoutBtn').classList.add('hidden'); $('#accountBtn').classList.add('hidden'); }
function showApp(user){
 currentUser=user;$('#authScreen').classList.add('hidden');$('#logoutBtn').classList.remove('hidden');$('#accountBtn').classList.remove('hidden');
 $('#adminNav').classList.toggle('hidden',user.role!=='admin');
 $('#accountBtn').textContent=user.username;
}
async function startApp(){
 setAuthMode('login');
 try{
  const s=await api('/auth/me');
  if(s.user){await enterWorkspace(s.user);return}
 }catch(e){}
 showAuth();
}
async function enterWorkspace(user){
 showApp(user);
 try{
  const result=await api('/workspace');
  db=result.workspace||{cases:[]};
  if(!Array.isArray(db.cases))db={cases:[]};
  if(!db.cases.length){const c={id:uid(),name:'My first investigation',description:'A workspace for verified public-source research.',created:new Date().toISOString(),entities:[],findings:[],links:[]};db.cases.push(c);await api('/workspace',{method:'PUT',body:JSON.stringify({workspace:db})});}
  active=db.cases[0].id;refreshCaseSelect();go('overview');
 }catch(e){toast('Workspace error: '+e.message);showAuth()}
}
$('#authForm').onsubmit=async e=>{
 e.preventDefault();let fd=new FormData(e.target),body=Object.fromEntries(fd.entries());
 $('#authError').textContent='';
 if(authMode==='register'&&body.password!==body.confirm){$('#authError').textContent='Passwords do not match.';return}
 try{
  const result=await api(authMode==='register'?'/auth/register':'/auth/login',{method:'POST',body:JSON.stringify(body)});
  await enterWorkspace(result.user);
 }catch(err){$('#authError').textContent=err.message}
};
$('#logoutBtn').onclick=async()=>{try{await api('/auth/logout',{method:'POST',body:'{}'})}catch{}currentUser=null;db={cases:[]};active=null;showAuth();setAuthMode('login')};
$('#accountBtn').onclick=()=>{if(!currentUser)return;alert(`Signed in as ${currentUser.username}\\nEmail: ${currentUser.email}\\nAccount ID: ${currentUser.id}`)};
startApp();


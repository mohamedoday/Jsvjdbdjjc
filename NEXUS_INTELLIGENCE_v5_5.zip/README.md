# NEXUS INTELLIGENCE V5.4 — Accounts + SQLite

## Requirements
- Node.js 18 or newer
- npm

## Setup (Windows PowerShell)
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Install dependencies:
   `npm install`
4. Create a session secret and set it for this terminal:
   `$env:SESSION_SECRET = [guid]::NewGuid().ToString() + [guid]::NewGuid().ToString()`
5. Start:
   `npm start`
6. Open `http://localhost:3000`.

On Linux/macOS:
```bash
npm install
export SESSION_SECRET="$(openssl rand -hex 32)"
npm start
```

## Accounts and database
- Register with a username, email, and password (minimum 10 characters).
- Passwords are hashed with bcrypt (12 rounds); plaintext passwords are never stored.
- User accounts, email, password hashes, and per-user workspaces are stored in `data/nexus.sqlite`.
- Login sessions are stored in a separate SQLite file, `data/sessions.sqlite`.
- Each account gets its own investigation workspace.
- Login attempts are rate-limited; session cookies are HttpOnly and SameSite=Strict.
- Sign out destroys the server session.

## Important
- This is a self-hosted starter, intended for localhost or a trusted private network.
- For public internet deployment, use HTTPS, a strong secret stored in environment variables, backups, and a reverse proxy. Do not expose the development server directly to the internet.
- There is no email verification or password-reset email flow yet. Do not use a password you use on other services.
- Database files are created automatically on first launch. Back up the `data` folder while the server is stopped.
- V5.3 research UI remains; analysis is local rule-based summarization, not a connected LLM.

## Owner-only Admin Console (V5.5)
Set `ADMIN_EMAIL` in the server environment to your own account email before starting.
Register or sign in with that exact email. Only that account receives the owner role.
The server checks the configured email on every admin API request. Other accounts cannot
gain access by editing browser code or local storage. The console displays account totals,
workspace/case counts, and recent account registrations. There is no public admin signup,
client-side role editor, or endpoint to promote another account.

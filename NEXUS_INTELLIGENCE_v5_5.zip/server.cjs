const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'nexus.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS workspaces (
 user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 data TEXT NOT NULL DEFAULT '{"cases":[]}',
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);
const secret = process.env.SESSION_SECRET;
if (!secret || secret.length < 32) {
 console.error('SESSION_SECRET must be set to a random string of at least 32 characters.');
 process.exit(1);
}
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
 defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
 fontSrc: ["'self'", 'https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], upgradeInsecureRequests: null
}}}));
app.use(express.json({limit:'2mb'}));
app.use(session({
 store: new SQLiteStore({ db: 'sessions.sqlite', dir: DATA_DIR, concurrentDB: true }),
 name: 'nexus.sid', secret, resave: false, saveUninitialized: false,
 cookie: { httpOnly:true, sameSite:'strict', secure: process.env.NODE_ENV === 'production', maxAge: 1000*60*60*8 }
}));
const authLimiter=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:true,legacyHeaders:false,message:{error:'Too many attempts. Try again in 15 minutes.'}});
function requireAuth(req,res,next){if(!req.session.userId)return res.status(401).json({error:'Please sign in again.'});next()}
function validEmail(v){return typeof v==='string'&&v.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
function validUsername(v){return typeof v==='string'&&/^[a-zA-Z0-9_.-]{3,32}$/.test(v)}
const ADMIN_EMAIL = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
function publicUser(row){return {id:row.id,username:row.username,email:row.email,createdAt:row.created_at,role:ADMIN_EMAIL && row.email.toLowerCase()===ADMIN_EMAIL?'admin':'user'}}
function requireAdmin(req,res,next){
 const user=db.prepare('SELECT id,email FROM users WHERE id=?').get(req.session.userId);
 if(!ADMIN_EMAIL || !user || user.email.toLowerCase()!==ADMIN_EMAIL)
  return res.status(403).json({error:'Admin access is restricted to the configured owner account.'});
 next();
}
app.post('/api/auth/register',authLimiter,async(req,res)=>{
 const {username,email,password}=req.body||{};
 if(!validUsername(username))return res.status(400).json({error:'Username must be 3–32 characters: letters, numbers, dot, dash, underscore.'});
 if(!validEmail(email))return res.status(400).json({error:'Enter a valid email address.'});
 if(typeof password!=='string'||password.length<10||password.length>128)return res.status(400).json({error:'Password must be 10–128 characters.'});
 try{
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare('INSERT INTO users(username,email,password_hash) VALUES(?,?,?)').run(username,email,hash);
  const user=db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  db.prepare('INSERT INTO workspaces(user_id,data) VALUES(?,?)').run(user.id,JSON.stringify({cases:[]}));
  req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Could not create secure session.'});req.session.userId=user.id;res.status(201).json({user:publicUser(user)})});
 }catch(e){if(String(e.code)==='SQLITE_CONSTRAINT_UNIQUE')return res.status(409).json({error:'Username or email is already registered.'});res.status(500).json({error:'Could not create account.'})}
});
app.post('/api/auth/login',authLimiter,async(req,res)=>{
 const {email,password}=req.body||{};
 if(!validEmail(email)||typeof password!=='string')return res.status(400).json({error:'Enter your email and password.'});
 const user=db.prepare('SELECT * FROM users WHERE email=? COLLATE NOCASE').get(email);
 const ok=user?await bcrypt.compare(password,user.password_hash):false;
 if(!ok)return res.status(401).json({error:'Incorrect email or password.'});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Could not start secure session.'});req.session.userId=user.id;res.json({user:publicUser(user)})});
});
app.get('/api/auth/me',requireAuth,(req,res)=>{
 const user=db.prepare('SELECT * FROM users WHERE id=?').get(req.session.userId);
 if(!user){req.session.destroy(()=>{});return res.status(401).json({error:'Account not found.'})}
 res.json({user:publicUser(user)});
});
app.post('/api/auth/logout',requireAuth,(req,res)=>req.session.destroy(err=>{res.clearCookie('nexus.sid',{httpOnly:true,sameSite:'strict'});if(err)return res.status(500).json({error:'Could not sign out.'});res.json({ok:true})}));
app.get('/api/workspace',requireAuth,(req,res)=>{
 const row=db.prepare('SELECT data FROM workspaces WHERE user_id=?').get(req.session.userId);
 try{res.json({workspace:row?JSON.parse(row.data):{cases:[]}})}catch{res.status(500).json({error:'Workspace data is corrupted.'})}
});
app.put('/api/workspace',requireAuth,(req,res)=>{
 const workspace=req.body?.workspace;
 if(!workspace||!Array.isArray(workspace.cases)||JSON.stringify(workspace).length>1_500_000)return res.status(400).json({error:'Invalid workspace or data exceeds size limit.'});
 const data=JSON.stringify(workspace);
 db.prepare(`INSERT INTO workspaces(user_id,data,updated_at) VALUES(?,?,datetime('now'))
 ON CONFLICT(user_id) DO UPDATE SET data=excluded.data,updated_at=datetime('now')`).run(req.session.userId,data);
 res.json({ok:true});
});
app.get('/api/admin/overview',requireAuth,requireAdmin,(req,res)=>{
 const totals=db.prepare(`SELECT COUNT(*) AS users,
 (SELECT COUNT(*) FROM workspaces) AS workspaces,
 (SELECT COALESCE(SUM(json_array_length(json_extract(data,'$.cases'))),0) FROM workspaces) AS cases
 FROM users`).get();
 const recent=db.prepare('SELECT id,username,email,created_at FROM users ORDER BY id DESC LIMIT 12').all()
 .map(u=>({...publicUser(u),createdAt:u.created_at}));
 res.json({totals,recent});
});
app.use(express.static(path.join(__dirname,'public'),{extensions:['html'],maxAge:process.env.NODE_ENV==='production'?'1h':0}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public/index.html')));
app.listen(PORT,'0.0.0.0',()=>console.log(`NEXUS V5.4 listening on http://localhost:${PORT}`));

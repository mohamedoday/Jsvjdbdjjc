const express = require("express");
const helmet = require("helmet");
const dns = require("node:dns").promises;
const tls = require("node:tls");
const https = require("node:https");
const path = require("node:path");
const multer = require("multer");

const app = express();
const PORT = process.env.PORT || 3030;
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });

function validHost(value) {
  if (typeof value !== "string") return false;
  const host = value.trim().toLowerCase();
  if (host.length > 253 || !/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*$/.test(host)) return false;
  return host.includes(".");
}
function validIp(value) {
  const net = require("node:net");
  return net.isIP(value) !== 0;
}
function getJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { "User-Agent": "NEXUS-INTELLIGENCE/1.0 contact: local-user" }, timeout: 10000 }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(data) }); }
        catch { reject(new Error("The upstream service returned an unreadable response.")); }
      });
    }).on("error", reject).on("timeout", function(){ this.destroy(new Error("Request timed out.")); });
  });
}
app.get("/api/health", (_req,res) => res.json({ ok:true, app:"NEXUS INTELLIGENCE", mode:"passive-and-authorized" }));

app.post("/api/dns", async (req,res) => {
  const host = String(req.body.host || "").trim().toLowerCase();
  if (!validHost(host)) return res.status(400).json({ error:"Enter a valid public domain name." });
  const types = ["A","AAAA","MX","NS","TXT","CNAME"];
  const results = {};
  await Promise.all(types.map(async type => {
    try {
      const rows = await dns.resolve(host, type);
      results[type] = rows.map(row => typeof row === "object" ? row : String(row));
    } catch (e) { results[type] = { note: e.code === "ENODATA" || e.code === "ENOTFOUND" ? "No records returned" : "Lookup unavailable" }; }
  }));
  res.json({ host, checkedAt:new Date().toISOString(), records:results, source:"System DNS resolver" });
});

app.post("/api/rdap", async (req,res) => {
  const query = String(req.body.query || "").trim();
  if (!validIp(query) && !validHost(query)) return res.status(400).json({ error:"Enter a valid IP address or domain." });
  try {
    const url = `https://rdap.org/${validIp(query) ? "ip" : "domain"}/${encodeURIComponent(query)}`;
    const out = await getJson(url);
    if (out.status >= 400) return res.status(502).json({ error:"RDAP registry did not return a record." });
    const d = out.data;
    res.json({
      query, handle:d.handle || d.ldhName || d.name || null,
      port43:d.port43 || null,
      country:d.country || null,
      status:d.status || [],
      events:(d.events || []).map(x=>({ action:x.eventAction, date:x.eventDate })),
      nameservers:(d.nameservers || []).map(x=>x.ldhName),
      entities:(d.entities || []).map(x=>({ roles:x.roles, handle:x.handle })),
      notices:(d.notices || []).map(x=>({ title:x.title, description:(x.description||[]).join(" ") })),
      source:"RDAP public registry", checkedAt:new Date().toISOString()
    });
  } catch(e) { res.status(502).json({ error:"RDAP lookup failed: " + e.message }); }
});

app.post("/api/tls", async (req,res) => {
  const host = String(req.body.host || "").trim().toLowerCase();
  if (!validHost(host)) return res.status(400).json({ error:"Enter a valid public domain you own or are authorized to assess." });
  const socket = tls.connect({ host, port:443, servername:host, timeout:8000, rejectUnauthorized:false }, () => {
    const cert = socket.getPeerCertificate(true);
    const result = {
      host, protocol:socket.getProtocol(), authorized:socket.authorized,
      authorizationError:socket.authorizationError || null,
      subject:cert.subject || {}, issuer:cert.issuer || {},
      validFrom:cert.valid_from || null, validTo:cert.valid_to || null,
      fingerprint256:cert.fingerprint256 || null,
      subjectAltName:cert.subjectaltname || null,
      checkedAt:new Date().toISOString(),
      note:"Certificate details only; this does not perform a vulnerability scan."
    };
    socket.end(); res.json(result);
  });
  socket.on("error", e => res.status(502).json({ error:"TLS inspection failed: " + e.message }));
  socket.on("timeout", () => { socket.destroy(); if (!res.headersSent) res.status(504).json({error:"TLS inspection timed out."}); });
});

app.post("/api/metadata", upload.single("file"), (req,res) => {
  if (!req.file) return res.status(400).json({ error:"Choose a file first." });
  // The server intentionally does not retain or parse uploaded files.
  res.json({
    fileName:req.file.originalname, mimeType:req.file.mimetype,
    sizeBytes:req.file.size,
    note:"For privacy, file bytes are not saved. Use the browser-side metadata viewer for supported image EXIF fields."
  });
});

app.listen(PORT, "127.0.0.1", () => console.log(`NEXUS INTELLIGENCE running at http://127.0.0.1:${PORT}`));

# NEXUS INTELLIGENCE

A local-first OSINT and authorized asset-audit starter application with:
- Web interface (Express + static frontend)
- Windows/macOS/Linux desktop shell (Electron)
- DNS record lookup (A, AAAA, MX, NS, TXT, CNAME)
- Public RDAP lookup for domains and IP addresses
- TLS certificate inspection on HTTPS port 443
- Browser-local basic image metadata inspection
- Local case notes and JSON/TXT export

## Requirements
- Node.js 20 or newer
- npm

## Run as a web app
```bash
npm install
npm start
```
Open http://127.0.0.1:3030

## Run as a desktop app
After `npm install`, run:
```bash
npm run desktop
```
The desktop launcher starts the local API automatically.

## Package as a Windows installer
This starter includes Electron but not a signed installer pipeline. To create distributables, add `electron-builder` and configure Windows targets after testing on your own machine.

## Security and privacy
- The server binds only to 127.0.0.1.
- Uploaded files are not stored; the metadata screen reads image bytes in the browser.
- Cases are stored in browser localStorage on the current device/browser.
- DNS, RDAP, and TLS features make external requests to resolve public records.
- No port scanning, brute forcing, credential collection, account enumeration, exploitation, or access-control bypass is included.
- Only investigate domains/IPs you own or have explicit authorization to assess.
- Do not expose this local service directly to the public internet.

## Known limitations
- RDAP coverage and fields depend on the relevant registry.
- DNS results depend on the machine's configured resolver.
- TLS inspection is a basic certificate presentation check, not a compliance or vulnerability assessment.
- Basic image dimension reading is implemented; full EXIF parsing can be added in a later version.
- The desktop shell expects the local Express server to be started separately.
